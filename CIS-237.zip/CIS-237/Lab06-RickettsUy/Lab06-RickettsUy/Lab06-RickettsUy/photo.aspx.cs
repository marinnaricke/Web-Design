﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab06_RickettsUy
{
    public partial class photo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ImagePhoto.ImageUrl = "images/Chrysanthemum.jpg";
            ImagePhoto.Width = Unit.Percentage(100);
        }

        protected void CheckBoxHide_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBoxHide.Checked)
            {
                ImagePhoto.Visible = false;
            }
            else
            {
                ImagePhoto.Visible = true;
            }
        }

        protected void RB_Sizes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RB_Sizes.SelectedItem.Text.Equals("Small"))
            {
                ImagePhoto.Width = Unit.Percentage(50);
            }
            else if (RB_Sizes.SelectedItem.Text.Equals("Medium"))
            {
                ImagePhoto.Width = Unit.Percentage(75);
            }
            else if (RB_Sizes.SelectedItem.Text.Equals("Large"))
            {
                ImagePhoto.Width = Unit.Percentage(100);
            }
        }

        protected void CheckBoxBorder_CheckedChanged(object sender, EventArgs e)
        {
            if (CheckBoxBorder.Checked)
            {
                ImagePhoto.BorderWidth = Unit.Pixel(5);
                ImagePhoto.BorderColor = System.Drawing.Color.Black;
                RB_Border_Colors.Enabled = true;
            }
            else
            {
                ImagePhoto.BorderWidth = Unit.Pixel(0);
                RB_Border_Colors.Enabled = false;
            }

        }

        protected void RB_Border_Colors_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (RB_Border_Colors.SelectedItem.Text.Equals("Red"))
            {
                ImagePhoto.BorderColor = System.Drawing.Color.Red;
            }
            else if (RB_Border_Colors.SelectedItem.Text.Equals("Blue"))
            {
                ImagePhoto.BorderColor = System.Drawing.Color.Blue;
            }
            else if (RB_Border_Colors.SelectedItem.Text.Equals("Yellow"))
            {
                ImagePhoto.BorderColor = System.Drawing.Color.Yellow;
            }
        }
    }
}