﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab06_RickettsUy
{
    public partial class calendar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            if (RB_Dates.SelectedItem.Text.Equals("Begin Date"))
            {
                LabelBeginDate.Text = Calendar1.SelectedDate.Date.ToLongDateString();
            }
            else if (RB_Dates.SelectedItem.Text.Equals("End Date"))
            {
                LabelEndDate.Text = Calendar1.SelectedDate.Date.ToLongDateString();
                DateTime startDate;
                DateTime endDate;
                TimeSpan dateDiff;

                startDate = Convert.ToDateTime(LabelBeginDate.Text);
                endDate = Convert.ToDateTime(LabelEndDate.Text);
                dateDiff = endDate - startDate;

                LabelDays.Text = dateDiff.Days.ToString() + " days";

                if (dateDiff.Days < 0)
                {
                    LabelError.Text = "Begin date can not be greater than end date!";
                }
                else
                {
                    LabelError.Text = "";
                }
            }
        }
    }
}