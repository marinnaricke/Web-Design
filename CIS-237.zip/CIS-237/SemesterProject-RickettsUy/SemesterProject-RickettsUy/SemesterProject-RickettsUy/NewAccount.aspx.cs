﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SemesterProject_RickettsUy
{
    public partial class NewAccount : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (Page.IsValid)
                {
                    SDS_NewAccount.Insert();
                    LabelMessage.Text = TextBoxFirstName.Text + " your account has been created!";
                    Clear_Fields();
                }
                
            }
            catch
            {
                LabelMessage.Text = "Error creating your account.";
            }
        }

        protected void Validate_Password_Length(object source, ServerValidateEventArgs args)
        {
            if (args.Value.Length < 8)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }

        protected void Clear_Fields()
        {
            TextBoxFirstName.Text = "";
            TextBoxLastName.Text = "";
            TextBoxEmail.Text = "";
            TextBoxEmail2.Text = "";
            TextBoxAddress.Text = "";
            TextBoxCity.Text = "";
            TextBoxZipcode.Text = "";
            TextBoxPassword.Text = "";
        }


    }
}