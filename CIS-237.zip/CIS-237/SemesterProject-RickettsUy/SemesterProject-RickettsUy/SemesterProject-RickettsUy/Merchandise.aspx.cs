﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SemesterProject_RickettsUy
{
    public partial class Mechandise : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["AccountID"] == null)
            {
                Response.Redirect("Login.aspx");
            }
            else if (Application["CurrentCustomer"] != null)
            {
                LabelCustomer.Text = Application["CurrentCustomer"].ToString();
            }
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SDS_Cart.Insert();
                LabelMessage.Text = "The item was added to your wish list!";
                ClearData();
            }
            catch
            {
                LabelMessage.Text = "An error has occurred. Sorry for the inconvience.";
            }
        }

        protected void ClearData()
        {
            LabelItem.Text = "";
            LabelIN.Text = "";
            LabelBrand.Text = "";
            LabelPrice.Text = "";
            RBL_Size.SelectedItem.Selected = false;
            TextBoxQuantity.Text = "";
        }

        protected void GV_Inventory_SelectedIndexChanged(object sender, EventArgs e)
        {
            LabelItem.Text = GV_Inventory.SelectedRow.Cells[1].Text.ToString();
            LabelIN.Text = GV_Inventory.SelectedRow.Cells[2].Text.ToString();
            LabelBrand.Text = GV_Inventory.SelectedRow.Cells[4].Text.ToString();
            LabelPrice.Text = GV_Inventory.SelectedRow.Cells[5].Text.ToString();

            ItemImage.Visible = true;
            ItemImage.ImageUrl = "Upload/" + GV_Inventory.SelectedRow.Cells[7].Text;
        }
    }
}