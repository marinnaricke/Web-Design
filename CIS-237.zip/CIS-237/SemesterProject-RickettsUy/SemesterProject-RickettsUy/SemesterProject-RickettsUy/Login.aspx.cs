﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SemesterProject_RickettsUy
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetCookie();
                Session.Clear();
            }
        }

        protected void ButtonLogin_Click(object sender, EventArgs e)
        {
            try
            {
                System.Data.DataView dv;
                SDS_Accounts.Select(DataSourceSelectArguments.Empty);
                dv = (System.Data.DataView)SDS_Accounts.Select(DataSourceSelectArguments.Empty);
                System.Data.DataRow dr;
                dr = dv.Table.Rows[0];
                if (dr.ItemArray[3].ToString() == TextBoxEmail.Text
                    && dr.ItemArray[8].ToString() == TextBoxPassword.Text)
                {

                    // Store the AccountID in a session variable called AccountID
                    Session["AccountID"] = dr.ItemArray[0].ToString();
                    // Store the First and Last name in a session variable called AccountName
                    Session["AccountName"] = dr.ItemArray[1].ToString() + " " + dr.ItemArray[2].ToString();
                    // Remove the data from the Application variables
                    Application.Clear();

                    // If checked then set cookie
                    if (CB_RememberMe.Checked == true)
                    {
                        //Create a cookie !
                        SetCookie();
                    }

                 }
                Application["CurrentCustomer"] = Session["AccountID"];
                Application["CustomerName"] = Session["AccountName"];
                LabelMessage.Text = Session["AccountName"] + " you are now logged in!";
            }
            catch
            {
                LabelMessage.Text = "Invalid email address or password.";
            }
        }

        protected void GetCookie()
        {
            try
            {
                if (CB_RememberMe.Checked == true)
                {
                    if (Request.Cookies["MyAccount"] != null)
                    {
                        TextBoxEmail.Text = Request.Cookies["MyAccount"]["Email"].ToString();
                        TextBoxPassword.Attributes.Add("value", Request.Cookies["MyAccount"]["Password"].ToString());

                        LabelMessage.Text = Request.Cookies["MyAccount"]["AccountHolder"].ToString() + " your last login was " +
                        Request.Cookies["MyAccount"]["LastVisit"].ToString();
                    }
                }
            }
            catch
            {

            }
        }

        protected void DeleteCookie()
        {
            try
            {
                Response.Cookies["MyAccount"].Expires = DateTime.Now;
                TextBoxEmail.Attributes.Add("value", "");
                TextBoxPassword.Attributes.Add("value", "");
            }
            catch
            {
                LabelMessage.Text = "An error occurred when deleting the cookie!";
            }

        }

        protected void SetCookie()
        {
            try
            {
                Response.Cookies["MyAccount"]["Email"] = TextBoxEmail.Text;
                Response.Cookies["MyAccount"]["AccountHolder"] = Session["AccountName"].ToString();
                Response.Cookies["MyAccount"]["AID"] = Session["AccountID"].ToString();
                Response.Cookies["MyAccount"]["Password"] = TextBoxPassword.Text;
                Response.Cookies["MyAccount"]["LastVisit"] = DateTime.Now.ToString();
                Response.Cookies["MyAccount"].Expires = DateTime.Now.AddDays(1000);
            }
            catch
            {
                LabelMessage.Text = "An error occurred when setting the cookie";
            }

        }

        protected void CB_RememberMe_CheckedChanged(object sender, EventArgs e)
        {
            if (CB_RememberMe.Checked == false)
            {
                // Add code to delete the cookie
                DeleteCookie();

                TextBoxEmail.Text = "";
                LabelMessage.Text = "";
            }
        }

        protected void ButtonNewUser_Click(object sender, EventArgs e)
        {
            Response.Redirect("NewAccount.aspx");
        }
    }
}