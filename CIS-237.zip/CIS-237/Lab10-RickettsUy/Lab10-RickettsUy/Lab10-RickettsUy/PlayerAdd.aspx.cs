﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab10_RickettsUy
{
    public partial class PlayerAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["UploadPath"] = Server.MapPath("Upload/");
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            LabelMessage.Text = "";
            try
            {
                if (Check_FileLength() == true && Check_FileType() == true)
                {
                    LabelFileName.Visible = true;
                    LabelFileName.Text = FileUploadImage.FileName.ToString();
                    FileUploadImage.PostedFile.SaveAs(Session["UploadPath"] + LabelFileName.Text);

                    SDS_Players.Insert();

                    LabelMessage.Text = TextBoxLastName.Text + " has been added";
                }
            }
            catch
            {
                LabelMessage.Text = "Error. Please check file type and size";
            }
        }

        protected bool Check_FileLength()
        {
            bool noErrors;
            try
            {
                if (FileUploadImage.PostedFile.ContentLength > 100000)
                {
                    LabelMessage.Text = LabelMessage.Text + " File size is too large. Must be under 100kb.";
                    noErrors = false;
                }
                else
                {
                    noErrors = true;
                }
                return noErrors;
            }
            catch
            {
                LabelMessage.Text = "Error. Please check file size.";
                noErrors = false;
                return noErrors;
            }
        }

        protected bool Check_FileType()
        {
            bool noErrors;
            try
            {
                if (FileUploadImage.PostedFile.ContentType == "image/png" ||
                    FileUploadImage.PostedFile.ContentType == "image/jpeg")
                {
                    noErrors = true;
                }
                else
                {
                    LabelMessage.Text = LabelMessage.Text + "File type is incorrect. Must be an image (jpg or png).";
                    noErrors = false;
                }
                return noErrors;
            }
            catch
            {
                LabelMessage.Text = "Error. Please check file type.";
                noErrors = false;
                return noErrors;
            }
        }
    }
}