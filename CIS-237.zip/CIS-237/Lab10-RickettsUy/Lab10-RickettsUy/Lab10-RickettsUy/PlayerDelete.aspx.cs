﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace Lab10_RickettsUy
{
    public partial class PlayerDelete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Session["UploadPath"] = Server.MapPath("Upload/");
        }

        protected void GV_Players_SelectedIndexChanged(object sender, EventArgs e)
        {
            PlayerImage.Visible = true;
            PlayerImage.ImageUrl = "Upload/" + GV_Players.SelectedRow.Cells[4].Text;
        }

        protected void GV_Players_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Select")
            {

            }
            else if (e.CommandName == "Delete")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GV_Players.Rows[index];
                File.Delete(Session["UploadPath"] + row.Cells[4].Text);
            }
        }
    }
}