﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab10_RickettsUy
{
    public partial class PlayerList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GV_Players_SelectedIndexChanged1(object sender, EventArgs e)
        {
            PlayerImage.Visible = true;
            PlayerImage.ImageUrl = "Upload/" + GV_Players.SelectedRow.Cells[4].Text;
        }
    }
}