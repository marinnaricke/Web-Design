﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab05_RickettsUy
{
    public partial class list2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ImageProducts2.Visible = false;
                DDL_Category2.Items.Add("Earrings");
                DDL_Category2.Items.Add("Rings");
                Load_Earrings();
            }
        }

        protected void Load_Earrings()
        {
            for (int counter = 1; counter <= 7; counter++)
            {
                LB_Products2.Items.Add("Earring-" + counter);
            }
        }

        protected void Load_Rings()
        {
            for (int counter = 1; counter <= 7; counter++)
            {
                LB_Products2.Items.Add("Ring-" + counter);
            }
        }

        protected void DDL_Category2_SelectedIndexChanged(object sender, EventArgs e)
        {
            ImageProducts2.Visible = false;
            switch (DDL_Category2.SelectedValue)
            {
                case "Earrings":
                    {
                        Clear_List();
                        Load_Earrings();
                        break;
                    }
                case "Rings":
                    {
                        Clear_List();
                        Load_Rings();
                        break;
                    }
            }
        }

        protected void Clear_List()
        {
            LB_Products2.Items.Clear();
        }

        protected void LB_Products2_SelectedIndexChanged(object sender, EventArgs e)
        {
                ImageProducts2.Visible = true;
            if (DDL_Category2.SelectedValue == "Earrings")
            {
                ImageProducts2.ImageUrl = "images/earrings/" + LB_Products2.SelectedItem.Text + ".jpg";

            }
            else
            {
                ImageProducts2.ImageUrl = "images/rings/" + LB_Products2.SelectedItem.Text + ".jpg";

            }
         }
        }
    }