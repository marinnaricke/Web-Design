﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab05_RickettsUy
{
    public partial class list3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ImageProducts3.Visible = false;
                ButtonAdd.Enabled = false;
                ButtonRemove.Enabled = false;
                ButtonRemoveAll.Enabled = false;
                DDL_Category3.Items.Add("Earrings");
                DDL_Category3.Items.Add("Rings");
                Load_Earrings();
            }
        }

        protected void Load_Earrings()
        {
            int loopCounter = 1;
            while (loopCounter <= 7)
            {
                LB_Products3.Items.Add("Earring-" + loopCounter);
                loopCounter++;
            }
        }

        protected void Load_Rings()
        {
            int loopCounter = 1;
            while (loopCounter <= 7)
            {
                LB_Products3.Items.Add("Ring-" + loopCounter);
                loopCounter++;
            }
        }

        protected void DDL_Category3_SelectedIndexChanged(object sender, EventArgs e)
        {
            ImageProducts3.Visible = false;
            switch (DDL_Category3.SelectedValue)
            {
                case "Earrings":
                    {
                        Clear_List();
                        Load_Earrings();
                        break;
                    }
                case "Rings":
                    {
                        Clear_List();
                        Load_Rings();
                        break;
                    }
            }
        }

         protected void Clear_List()
         {
            LB_Products3.Items.Clear();
         }

         protected void LB_Products3_SelectedIndexChanged(object sender, EventArgs e)
         {
             ImageProducts3.Visible = true;
             if (DDL_Category3.SelectedValue == "Earrings")
             {
                 ImageProducts3.ImageUrl = "images/earrings/" + LB_Products3.SelectedItem.Text + ".jpg";
                 ButtonAdd.Enabled = true;
             }
             else
             {
                 ImageProducts3.ImageUrl = "images/rings/" + LB_Products3.SelectedItem.Text + ".jpg";
                 ButtonAdd.Enabled = true;
             }

         }

         protected void LB_Cart3_SelectedIndexChanged(object sender, EventArgs e)
         {
             ButtonRemove.Enabled = true;
             ButtonRemoveAll.Enabled = true;
         }

        protected void ButtonAdd_Click(object sender, EventArgs e)
         {
             LB_Cart3.Items.Add(LB_Products3.SelectedItem.Text);
             LB_Products3.Items.Remove(LB_Products3.SelectedItem.Text);
             ImageProducts3.Visible = false;
             ButtonAdd.Enabled = false;
             ButtonRemoveAll.Enabled = true;
         }

        protected void ButtonRemove_Click(object sender, EventArgs e)
        {
            LB_Products3.Items.Add(LB_Cart3.SelectedItem.Text);
            LB_Cart3.Items.Remove(LB_Cart3.SelectedItem.Text);
            ButtonRemove.Enabled = false;
            ButtonRemoveAll.Enabled = false;
        }

        protected void ButtonRemoveAll_Click(object sender, EventArgs e)
        {
            LB_Cart3.Items.Clear();
            ButtonRemoveAll.Enabled = false;
            ButtonRemove.Enabled = false;
        }
    }
}