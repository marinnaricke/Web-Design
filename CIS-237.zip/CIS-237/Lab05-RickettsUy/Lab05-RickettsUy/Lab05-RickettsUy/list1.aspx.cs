﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab05_RickettsUy
{
    public partial class list1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ImageProducts1.Visible = false;
                Load_Products();
            }
        }

        protected void Load_Products()
        {
            for (int counter = 1; counter <= 7; counter++)
            {
                LB_Products1.Items.Add("Earring-" + counter);
            }
        }

        protected void LB_Products1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ImageProducts1.Visible = true;
            ImageProducts1.ImageUrl = "images/earrings/" + LB_Products1.SelectedItem.Text + ".jpg";
        }
    }
}