﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace c07d
{
    public partial class KennelList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GV_Kennels_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                System.Data.DataView dv;
                SDS_KennelData.Select(DataSourceSelectArguments.Empty);
                dv = (System.Data.DataView)SDS_KennelData.Select(DataSourceSelectArguments.Empty);
                System.Data.DataRow dr;
                dr = dv.Table.Rows[0];  //Get the first row
                if (dr.ItemArray[0].ToString() == GV_Kennels.SelectedRow.Cells[1].Text.ToString())
                {
                    LabelKennelID.Text = dr.ItemArray[0].ToString();
                    LabelKennelName.Text = dr.ItemArray[1].ToString();
                    LabelLocation.Text =  dr.ItemArray[2].ToString();
                    LabelAnnualFee.Text = dr.ItemArray[3].ToString();

                }
             }
             catch
             {
                 LabelMessage.Text = "Error retrieving record.";
             }

        }
    }
}