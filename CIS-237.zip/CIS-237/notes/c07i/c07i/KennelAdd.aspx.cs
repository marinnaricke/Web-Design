﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace c7i
{
    public partial class KennelAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SDS_Kennel.Insert();
                LabelMessage.Text = TextBoxKennelName.Text + 
                     " was added.";
                ClearData();
            }
            catch
            {
                LabelMessage.Text = "Error inserting record.";
            }
        }

        protected void ClearData()
        {
            TextBoxKennelName.Text = "";
            TextBoxLocation.Text = "";
            TextBoxAnnualFee.Text = "";
        }
    }
}