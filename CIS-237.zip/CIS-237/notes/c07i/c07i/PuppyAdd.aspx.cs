﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace c07i
{
    public partial class PuppyAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try 
            { 
                SDS_Puppy.Insert();
                LabelMessage.Text = TextBoxPuppyNane.Text + " was added.";
                Clear_Data();
            }
            catch 
            {
                LabelMessage.Text = "Error adding record.";
            }
        }

        protected void Clear_Data()
        {
            TextBoxPuppyNane.Text = "";
            TextBoxPhoto.Text = "";
            TextBoxBirthDate.Text = "";
        }
    }
}