﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab03_RickettsUy
{
    public partial class dates : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LabelCurrentDate.Text = DateTime.Today.ToShortDateString();
            LabelCurrentTime.Text = DateTime.Now.ToShortTimeString();
            LabelCurrentMonth.Text = DateTime.Today.Month.ToString();
            LabelCurrentDay.Text = DateTime.Today.Day.ToString();
            LabelCurrentYear.Text = DateTime.Today.Year.ToString();

            DateTime beginDate;
            beginDate = new DateTime(DateTime.Today.Year, 1, 1);
            
            DateTime endDate;
            endDate = DateTime.Today;
            
            TimeSpan numberOfDays;
            numberOfDays = endDate - beginDate;
            LabelNofDays.Text = numberOfDays.TotalDays.ToString();
        }
    }
}