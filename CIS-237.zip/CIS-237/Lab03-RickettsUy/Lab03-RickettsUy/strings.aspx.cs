﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab03_RickettsUy
{
    public partial class strings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {
            int chars = TextBoxDI.Text.Length;

            LabelSubmit.Text = TextBoxFN.Text.ToUpper() + " " + TextBoxLN.Text.ToUpper()
                + " thank you for your purchase." + "<br>" + "A confirmation email will be sent to: " + TextBoxEmail.Text
                + "<br>" + "Delivery Instructions character count is " + chars + ".";
        }
    }
}