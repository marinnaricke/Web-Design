﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab03_RickettsUy
{
    public partial class math : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            LabelResult.Text = (double.Parse(TextBoxFirstNumber.Text) +
                            double.Parse(TextBoxSecondNumber.Text)).ToString();
            LabelMessage.Text = ("Addition Successful");
        }
        protected void ButtonSubstract_Click(object sender, EventArgs e)
        {
            LabelResult.Text = (double.Parse(TextBoxFirstNumber.Text) -
                            double.Parse(TextBoxSecondNumber.Text)).ToString();
            LabelMessage.Text = ("Subtraction Successful");
        }

        protected void ButtonMultiply_Click(object sender, EventArgs e)
        {
            LabelResult.Text = (double.Parse(TextBoxFirstNumber.Text) *
                            double.Parse(TextBoxSecondNumber.Text)).ToString();
            LabelMessage.Text = ("Multiplication Successful");
        }

        protected void ButtonDivide_Click(object sender, EventArgs e)
        {
            try
            {
                LabelResult.Text = (double.Parse(TextBoxFirstNumber.Text) /
                                double.Parse(TextBoxSecondNumber.Text)).ToString();
                LabelMessage.Text = ("Division Successful");
            }
            catch (Exception ex)
            {
                LabelResult.Text = "Infinity";
            }
        }
    }
}