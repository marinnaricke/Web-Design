﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab08_RickettsUy
{
    public partial class clientadd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAddClient_Click(object sender, EventArgs e)
        {
            try
            { 
                SDS_Client.Insert();
                LabelAddMessage.Text = TextBoxFirstName.Text + " " + TextBoxLastName.Text + " was added.";
                ClearData();
            }
            catch
            {
                LabelAddMessage.Text = "Error adding client.";
            }
        }

        protected void ClearData()
        {
            TextBoxFirstName.Text = "";
            TextBoxLastName.Text = "";
            TextBoxEmail.Text = "";
            TextBoxStreetAdd.Text = "";
            TextBoxCity.Text = "";
            TextBoxZipcode.Text = "";
            RBList_Gender.SelectedItem.Selected = false;
        }
    }
}