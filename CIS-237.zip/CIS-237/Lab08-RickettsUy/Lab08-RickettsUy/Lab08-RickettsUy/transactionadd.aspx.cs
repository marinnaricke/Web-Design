﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab08_RickettsUy
{
    public partial class transactionadd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SDS_Transactions.Insert();
                LabelAddMessage.Text = LabelCompany.Text + " was added.";
                ClearData();
            }
           catch
            {
                LabelAddMessage.Text = "Error adding transaction.";
            }
        }

        protected void ClearData()
        {
            LabelCompany.Text = "";
            LabelSymbol.Text = "";
            LabelPrice.Text = "";
            RBL_Transaction.SelectedItem.Selected = false;
        }

        protected void GV_Market_SelectedIndexChanged(object sender, EventArgs e)
        {
            LabelCompany.Text = GV_Market.SelectedRow.Cells[1].Text.ToString();
            LabelSymbol.Text = GV_Market.SelectedRow.Cells[2].Text.ToString();
            LabelPrice.Text = GV_Market.SelectedRow.Cells[3].Text.ToString();
        }

    }
}