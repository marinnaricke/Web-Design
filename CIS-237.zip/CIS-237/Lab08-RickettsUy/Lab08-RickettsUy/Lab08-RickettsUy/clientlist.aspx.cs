﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab08_RickettsUy
{
    public partial class clientlist : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GV_Clients_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                System.Data.DataView dv;
                SDS_ClientData.Select(DataSourceSelectArguments.Empty);
                dv = (System.Data.DataView)SDS_ClientData.Select(DataSourceSelectArguments.Empty);
                System.Data.DataRow dr;
                dr = dv.Table.Rows[0];
                if (dr.ItemArray[0].ToString() == GV_Clients.SelectedRow.Cells[1].Text.ToString())
                {
                    LabelClientID.Text = dr.ItemArray[0].ToString();
                    LabelFirstName.Text = dr.ItemArray[1].ToString();
                    LabelLastName.Text = dr.ItemArray[2].ToString();
                    LabelEmail.Text = dr.ItemArray[3].ToString();
                    LabelStreet.Text = dr.ItemArray[4].ToString();
                    LabelCity.Text = dr.ItemArray[5].ToString();
                    LabelState.Text = dr.ItemArray[6].ToString();
                    LabelZip.Text = dr.ItemArray[7].ToString();
                    LabelGender.Text = dr.ItemArray[8].ToString();
                }
            }
            catch
            {
                LabelMessage.Text = "Error retrieving record.";
            }
        }
    }
}