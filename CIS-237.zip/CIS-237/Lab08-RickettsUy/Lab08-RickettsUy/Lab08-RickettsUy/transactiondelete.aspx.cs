﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab08_RickettsUy
{
    public partial class transactiondelete : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void ButtonDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SDS_TransactionData.Delete();
                LabelDeleteMessage.Text = "Transaction ID " + LabelTransID.Text  + " has been deleted.";
                Clear_Data();
                SDS_Transactions.DataBind();
                GV_Transactions.DataBind();
            }
            catch
            {
                LabelDeleteMessage.Text = "Error has occured when deleting this transaction.";
            }
        }

        protected void Clear_Data()
        {
            LabelTransID.Text = "";
            LabelCompany.Text = "";
            LabelAmount.Text = "";
        }
        protected void GV_Transactions_SelectedIndexChanged(object sender, EventArgs e)
        {
                    LabelTransID.Text = GV_Transactions.SelectedRow.Cells[1].Text.ToString();
                    LabelCompany.Text = GV_Transactions.SelectedRow.Cells[3].Text.ToString();
                    LabelAmount.Text = "$" + GV_Transactions.SelectedRow.Cells[7].Text.ToString();
        }
    }
}