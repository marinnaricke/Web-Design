﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab09_RickettsUy
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Application["CurrentTeam"] != null)
            {
                LabelCurrentTeam.Text = Application["CurrentTeam"].ToString();
            }
        }
    }
}