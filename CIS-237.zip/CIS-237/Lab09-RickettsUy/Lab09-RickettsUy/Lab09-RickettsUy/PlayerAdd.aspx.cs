﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab09_RickettsUy
{
    public partial class PlayerAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["AccountID"] == null)
            {
                //Redirect the user back to default.aspx
                Response.Redirect("default.aspx");
            }
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SDS_Players.Insert();
                LabelMessage.Text = TextBoxLastName.Text + " has been added.";
                Clear_Fields();
            }
            catch
            {
                LabelMessage.Text = "Error adding player.";
            }

        }

        protected void Clear_Fields()
        {
            TextBoxFirstName.Text = "";
            TextBoxLastName.Text = "";
            TextBoxBirthDate.Text = "";
            TextBoxEmail.Text = "";
            TextBoxHeight.Text = "";
            TextBoxWeight.Text = "";
            RB_Gender.ClearSelection();
        }
    }
}