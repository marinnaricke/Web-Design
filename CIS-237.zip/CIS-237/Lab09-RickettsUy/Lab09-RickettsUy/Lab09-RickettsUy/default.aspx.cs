﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab09_RickettsUy
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetCookie();
                Session.Clear();
            }

        }

                protected void ButtonLogin_Click(object sender, EventArgs e)
        {
           // try
           // {
                System.Data.DataView dv;
                SDS_Accounts.Select(DataSourceSelectArguments.Empty);
                dv = (System.Data.DataView)SDS_Accounts.Select(DataSourceSelectArguments.Empty);
                System.Data.DataRow dr;
                dr = dv.Table.Rows[0];
                if (dr.ItemArray[4].ToString() == TextBoxUserName.Text
                    && dr.ItemArray[3].ToString() == TextBoxPassword.Text)
                {
                    LabelMessage.Text = dr.ItemArray[1].ToString() +
                        " " + dr.ItemArray[2].ToString() +
                        " has logged in.";

                    // Store the AccountID in a session variable called AccountID
                    Session["AccountID"] = dr.ItemArray[0].ToString();
                    // Store the First and Last name in a session variable called AccountName
                    Session["AccountName"] = dr.ItemArray[1].ToString() + " " + dr.ItemArray[2].ToString();
                    // Remove the data from the Application variables
                    Application.Clear();

                    // If checked then set cookie
                    if (CB_RememberMe.Checked == true)
                    {
                        //Create a cookie !
                        SetCookie();
                    }
                }
                else
                {
                    LabelMessage.Text = "Invalid email address or password.";
                }
           // }
          //  catch
          //  {
          //      LabelMessage.Text = "Error: Invalid email address or password.";
           // }
        }
        protected void GetCookie()
        {
            //Use Request object to read cookie
          //  try
         //   {
                if (CB_RememberMe.Checked == true)
                {
                    if (Request.Cookies["MyAccount"] != null)
                    {
                        TextBoxUserName.Text = Request.Cookies["MyAccount"]["Email"].ToString();
                        TextBoxPassword.Attributes.Add("value", Request.Cookies["MyAccount"]["Password"].ToString());

                        LabelMessage.Text = Request.Cookies["MyAccount"]["AccountHolder"].ToString() + " your last login was " +
                        Request.Cookies["MyAccount"]["LastVisit"].ToString();
                    }
                }


         //   }
          //  catch
         //   {
         //       LabelMessage.Text = "An error has occurred when getting cookie!";
          //  }

        }

        protected void DeleteCookie()
        {
            try
            {
                Response.Cookies["MyAccount"].Expires = DateTime.Now;
                TextBoxUserName.Attributes.Add("value", "");
                TextBoxPassword.Attributes.Add("value", "");
            }
            catch
            {
                LabelMessage.Text = "An error occurred when deleting the cookie!";
            }
                
        }

        protected void SetCookie()
        {
            //The Response Object is used to create a cookie
            //Must have an expiration date
            try
            {
                Response.Cookies["MyAccount"]["Email"] = TextBoxUserName.Text;
                Response.Cookies["MyAccount"]["AccountHolder"] = Session["AccountName"].ToString();
                Response.Cookies["MyAccount"]["AID"] = Session["AccountID"].ToString();
                Response.Cookies["MyAccount"]["Password"] = TextBoxPassword.Text;
                Response.Cookies["MyAccount"]["LastVisit"] = DateTime.Now.ToString();
                Response.Cookies["MyAccount"].Expires = DateTime.Now.AddDays(1000);
            }
            catch
            {
                LabelMessage.Text = "An error occurred when setting the cookie";
            }

        }

        protected void CB_RememberMe_CheckedChanged(object sender, EventArgs e)
        {

            if (CB_RememberMe.Checked == false)
            {
                // Add code to delete the cookie
                DeleteCookie();

                TextBoxUserName.Text = "";
                LabelMessage.Text = "";
            }
        }
    }
}