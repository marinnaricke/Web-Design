﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab09_RickettsUy
{
    public partial class TeamAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["AccountID"] == null)
            {
                //Redirect the user back to default.aspx
                Response.Redirect("default.aspx");
            }
        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SDS_Teams.Insert();
                LabelMessage.Text = TextBoxTeamName.Text + " was added.";
                TextBoxTeamName.Text = "";
                GV_Teams.DataBind();
                SDS_Teams.DataBind();
            }
            catch
            {
                LabelMessage.Text = "Error adding team " + TextBoxTeamName.Text;
            }
        }

        protected void GV_Teams_SelectedIndexChanged(object sender, EventArgs e)
        {
            Application["CurrentTeam"] = GV_Teams.SelectedRow.Cells[2].Text;
            Response.Redirect("PlayerList.aspx?TID=" + GV_Teams.SelectedRow.Cells[1].Text +
                "&TN=" + GV_Teams.SelectedRow.Cells[2].Text);
        }
    }
}