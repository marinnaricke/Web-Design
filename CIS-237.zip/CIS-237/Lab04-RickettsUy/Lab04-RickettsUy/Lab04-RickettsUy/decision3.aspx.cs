﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab04_RickettsUy
{
    public partial class decision3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Calculate_Click(object sender, CommandEventArgs e)
        {
            try
            {
                if (e.CommandName.Equals("BC"))
                {
                    LabelCalc.Text = "";
                    LabelOperand1.Text = "";
                    LabelOperation.Text = "";
                    LabelOperand2.Text = "";
                    LabelAnswer.Text = "";
                }
                else if (e.CommandName.Equals("D"))
                {
                    LabelOperand1.Text = LabelCalc.Text;
                    LabelOperation.Text = "/";
                    LabelCalc.Text = "";
                    ButtonDivide.Enabled = false;
                    ButtonMultiply.Enabled = false;
                    ButtonSubtract.Enabled = false;
                    ButtonAdd.Enabled = false;
                    ButtonEquals.Enabled = true;
                }
                else if (e.CommandName.Equals("M"))
                {
                    LabelOperand1.Text = LabelCalc.Text;
                    LabelOperation.Text = "*";
                    LabelCalc.Text = "";
                    ButtonDivide.Enabled = false;
                    ButtonMultiply.Enabled = false;
                    ButtonSubtract.Enabled = false;
                    ButtonAdd.Enabled = false;
                    ButtonEquals.Enabled = true;
                }
                else if (e.CommandName.Equals("S"))
                {
                    LabelOperand1.Text = LabelCalc.Text;
                    LabelOperation.Text = "-";
                    LabelCalc.Text = "";
                    ButtonDivide.Enabled = false;
                    ButtonMultiply.Enabled = false;
                    ButtonSubtract.Enabled = false;
                    ButtonAdd.Enabled = false;
                    ButtonEquals.Enabled = true;
                }
                else if (e.CommandName.Equals("A"))
                {
                    LabelOperand1.Text = LabelCalc.Text;
                    LabelOperation.Text = "+";
                    LabelCalc.Text = "";
                    ButtonDivide.Enabled = false;
                    ButtonMultiply.Enabled = false;
                    ButtonSubtract.Enabled = false;
                    ButtonAdd.Enabled = false;
                    ButtonEquals.Enabled = true;
                }
                else if (e.CommandName.Equals("E"))
                {
                    double operand1,
                           operand2,
                           answer;
                    LabelOperand2.Text = LabelCalc.Text;
                    operand1 = double.Parse(LabelOperand1.Text);
                    operand2 = double.Parse(LabelOperand2.Text);

                    if (LabelOperation.Text.Equals("/"))
                    {
                        if (LabelOperand2.Text == "0")
                        {
                            LabelAnswer.Text = "Divide by zero";
                            LabelCalc.Text = "Divide by zero";
                        }
                        else
                        {
                            answer = operand1 / operand2;
                            LabelAnswer.Text = answer.ToString();
                            LabelCalc.Text = LabelAnswer.Text;
                            ButtonEquals.Enabled = false;
                        }

                    }
                    else if (LabelOperation.Text.Equals("*"))
                    {
                        answer = operand1 * operand2;
                        LabelAnswer.Text = answer.ToString();
                        LabelCalc.Text = LabelAnswer.Text;
                        ButtonEquals.Enabled = false;
                    }
                    else if (LabelOperation.Text.Equals("-"))
                    {
                        answer = operand1 - operand2;
                        LabelAnswer.Text = answer.ToString();
                        LabelCalc.Text = LabelAnswer.Text;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        answer = operand1 + operand2;
                        LabelAnswer.Text = answer.ToString();
                        LabelCalc.Text = LabelAnswer.Text;
                        ButtonEquals.Enabled = false;
                    }
                }
                else if (e.CommandName.Equals("7"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("8"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("9"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("4"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("5"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("6"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("1"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("2"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("3"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
                else if (e.CommandName.Equals("0"))
                {
                    if (LabelOperand1.Text.Length == 0)
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = true;
                        ButtonMultiply.Enabled = true;
                        ButtonSubtract.Enabled = true;
                        ButtonAdd.Enabled = true;
                        ButtonEquals.Enabled = false;
                    }
                    else
                    {
                        LabelCalc.Text = LabelCalc.Text + e.CommandName;
                        ButtonDivide.Enabled = false;
                        ButtonMultiply.Enabled = false;
                        ButtonSubtract.Enabled = false;
                        ButtonAdd.Enabled = false;
                        ButtonEquals.Enabled = true;
                    }
                }
            }
            catch
            {
                LabelAnswer.Text = "Error - Please check your input.";
                LabelCalc.Text = "Error - Please check your input.";
            }
            }
        }
    }