﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab04_RickettsUy
{
    public partial class decision1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonCompute_Click(object sender, EventArgs e)
        {
            try
            {
                double grade1,
                       grade2,
                       grade3,
                       average;
                grade1 = double.Parse(TextBoxGrade1.Text);
                grade2 = double.Parse(TextBoxGrade2.Text);
                grade3 = double.Parse(TextBoxGrade3.Text);
                average = (grade1 + grade2 + grade3)/3;
                if (average >= 90)
                {
                    LabelAvg.Text = average.ToString("00.00");
                    LabelLG.Text = "A";
                    ImageLetter.ImageUrl = "images/A.jpg";
                }
                else if (average >= 80)
                {
                    LabelAvg.Text = average.ToString("00.00");
                    LabelLG.Text = "B";
                    ImageLetter.ImageUrl = "images/B.jpg";
                }
                else if (average >= 70)
                {
                    LabelAvg.Text = average.ToString("00.00");
                    LabelLG.Text = "C";
                    ImageLetter.ImageUrl = "images/C.jpg";
                }
                else if (average >= 60)
                {
                    LabelAvg.Text = average.ToString("00.00");
                    LabelLG.Text = "D";
                    ImageLetter.ImageUrl = "images/D.jpg";
                }
                else
                {
                    LabelAvg.Text = average.ToString("00.00");
                    LabelLG.Text = "F";
                    ImageLetter.ImageUrl = "images/F.jpg";
                }
            }
            catch
            {
                LabelAvg.Text = "Error, please check grade inputs.";
                LabelLG.Text = "Error, please check grade inputs.";
                ImageLetter.ImageUrl = "images/Q.jpg";
            }
        }

        protected void ClearPage_Click(object sender, EventArgs e)
        {
            ImageLetter.ImageUrl = "images/Q.jpg";
            LabelAvg.Text = "";
            LabelLG.Text = "";
            TextBoxGrade1.Text = "";
            TextBoxGrade2.Text = "";
            TextBoxGrade3.Text = "";
        }
    }
}