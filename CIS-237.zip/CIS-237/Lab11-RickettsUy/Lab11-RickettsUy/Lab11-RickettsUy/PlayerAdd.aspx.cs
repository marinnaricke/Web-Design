﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab11_RickettsUy
{
    public partial class PlayerAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButtonAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if(Page.IsValid)
                {
                    SDS_Players.Insert();
                    LabelMessage.Text = TextBoxFirstName.Text + " " + TextBoxLastName.Text + " has been added!";
                }
            }
            catch
            {
                LabelMessage.Text = "Error adding player.";
            }
        }

        protected void Validate_LastName_Length(object source, ServerValidateEventArgs args)
        {
            if (args.Value.Length < 3)
            {
                args.IsValid = false;
            }
            else
            {
                args.IsValid = true;
            }
        }
    }
}